package de.bassweep.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.view.WindowManager;
import android.graphics.*;
import android.media.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private Tone tone;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512);
        tone = new Tone();
        setContentView(new Pad());
    }
    @Override protected void onPause(){ super.onPause(); if(tone!=null) tone.stop(); }
    @Override protected void onDestroy(){ if(tone!=null) tone.stop(); super.onDestroy(); }

    final class Pad extends View {
        Paint p=new Paint(3); float x=-1,y=-1,f=70,g=.25f; boolean down=false;
        Pad(){super(MainActivity.this);}
        protected void onDraw(Canvas c){
            float w=getWidth(),h=getHeight(); c.drawColor(Color.rgb(5,6,17));
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(0x263b78ff);
            float step=Math.max(34,w/10); for(float a=0;a<w;a+=step)c.drawLine(a,0,a,h,p); for(float a=0;a<h;a+=step)c.drawLine(0,a,w,a,p);
            p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.create("sans-serif-light",0));
            p.setTextSize(Math.min(94,w*.22f)); p.setColor(Color.WHITE); c.drawText(Math.round(f)+" Hz",w/2,h*.18f,p);
            p.setTextSize(20); p.setColor(0xff9aa8df); c.drawText("BERÜHREN  •  BEWEGEN  •  LOSLASSEN",w/2,h*.23f,p);
            int[] ticks={20,40,60,80,100,120}; p.setTextSize(22); p.setColor(0xff879cff);
            for(int t:ticks){float xx=(t-20)/100f*w; c.drawText(""+t,xx,h-18,p);}
            if(down){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(0x886b7cff);c.drawCircle(x,y,38,p);p.setColor(0xffa18aff);c.drawCircle(x,y,18,p);p.setStyle(Paint.Style.FILL);c.drawCircle(x,y,6,p);}
        }
        void update(float a,float b){x=Math.max(0,Math.min(getWidth(),a));y=Math.max(0,Math.min(getHeight(),b));f=20+x/Math.max(1,getWidth())*100;g=1-y/Math.max(1,getHeight());tone.target(f,g);invalidate();}
        public boolean onTouchEvent(MotionEvent e){
            if(e.getActionMasked()==MotionEvent.ACTION_DOWN){down=true;update(e.getX(),e.getY());tone.start(f,g);return true;}
            if(e.getActionMasked()==MotionEvent.ACTION_MOVE){if(down)update(e.getX(),e.getY());return true;}
            if(e.getActionMasked()==MotionEvent.ACTION_UP||e.getActionMasked()==MotionEvent.ACTION_CANCEL){down=false;x=y=-1;tone.stop();invalidate();return true;}
            return true;
        }
    }

    static final class Tone {
        static final int RATE=48000; AudioTrack track; Thread worker; AtomicBoolean running=new AtomicBoolean(false);
        volatile float tf=70,tg=.25f; volatile int gen=0;
        void target(float f,float g){tf=f;tg=g;}
        synchronized void start(float f,float g){
            stop(); tf=f;tg=g; int id=++gen;
            int min=AudioTrack.getMinBufferSize(RATE,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT);
            AudioFormat fmt=new AudioFormat.Builder().setSampleRate(RATE).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build();
            AudioAttributes aa=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
            track=new AudioTrack(aa,fmt,Math.max(min,4096),AudioTrack.MODE_STREAM,AudioManager.AUDIO_SESSION_ID_GENERATE);
            final AudioTrack out=track; running.set(true); out.play();
            worker=new Thread(()->{short[] buf=new short[512];double phase=0;float cf=f,cg=0;
                while(running.get()&&gen==id){for(int i=0;i<buf.length;i++){cf+=(tf-cf)*.003f;cg+=(tg-cg)*.004f;double s=Math.sin(phase)*Math.min(.35f,Math.max(0,cg)*.35f);phase+=2*Math.PI*cf/RATE;if(phase>2*Math.PI)phase-=2*Math.PI;buf[i]=(short)(s*32767);}
                    if(out.write(buf,0,buf.length)<0)break;}
            },"BassSweep-Audio"); worker.setPriority(Thread.MAX_PRIORITY);worker.start();
        }
        synchronized void stop(){running.set(false);gen++;AudioTrack t=track;track=null;if(t!=null){try{t.pause();t.flush();t.stop();}catch(Exception ignored){}try{t.release();}catch(Exception ignored){}}}
    }
}
