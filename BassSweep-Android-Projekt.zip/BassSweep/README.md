# BassSweep – Android-Projekt

## Build nur mit dem Smartphone über GitHub
1. Erstelle auf GitHub ein neues, leeres Repository namens `BassSweep`.
2. Lade `BassSweep-Android-Projekt.zip` als einzelne Datei in das Repository hoch.
3. Erstelle im Repository die Datei `.github/workflows/build-bassweep.yml`.
4. Kopiere den Inhalt aus der separat bereitgestellten Datei `BassSweep-GitHub-Workflow.yml` hinein und speichere.
5. Öffne **Actions** → **Build BassSweep APK** → **Run workflow**.
6. Nach erfolgreichem Lauf den Workflow öffnen und unter **Artifacts** `BassSweep-debug` herunterladen.
7. Das heruntergeladene Artifact-ZIP entpacken. Darin liegt `app-debug.apk`.

## Funktionen
- Portrait, Vollbild, Display bleibt an
- Touchfeld: horizontal 20–120 Hz, vertikal 0–100 %
- Sinus, 48 kHz, Mono; Finger loslassen stoppt, jede neue Berührung startet neu
- Sanfte Frequenz-/Pegeländerung und begrenzter digitaler Ausgangspegel
- Normale Android-Audioausgabe; ein angeschlossenes Kabel wird normalerweise automatisch von Android verwendet

Hinweis: Die Lautstärke am Gerät/Verstärker zuerst niedrig einstellen. Viele Handy-Lautsprecher können 20 Hz nicht sinnvoll wiedergeben.
